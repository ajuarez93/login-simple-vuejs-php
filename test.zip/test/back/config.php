<?php

define('SERVER', '127.0.0.1');
define('USUARIO', 'root');
define('CONTRASENA', '12345678');
define('BASE', 'test');
