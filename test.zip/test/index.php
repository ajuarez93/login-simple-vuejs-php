<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once 'head.php' ?>
    <title>Bienvenido</title>
</head>

<body>
    <?php include_once 'menu.php' ?>

    <div class="container" style="margin-top: 60px;;">
        <h1>
            Bienvenido a tu panel de control
        </h1>
    </div>
   
</body>

</html>